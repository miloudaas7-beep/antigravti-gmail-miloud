module.exports=[57319,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sender_generate_route_actions_0hgsnwd.js.map