module.exports=[18092,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_campaign_hyper-generate_route_actions_0n12_5g.js.map