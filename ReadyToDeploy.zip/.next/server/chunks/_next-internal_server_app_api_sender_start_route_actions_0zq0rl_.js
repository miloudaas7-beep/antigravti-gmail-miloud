module.exports=[14028,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sender_start_route_actions_0zq0rl_.js.map