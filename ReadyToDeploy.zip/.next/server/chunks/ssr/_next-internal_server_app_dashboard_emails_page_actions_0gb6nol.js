module.exports=[72957,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_emails_page_actions_0gb6nol.js.map