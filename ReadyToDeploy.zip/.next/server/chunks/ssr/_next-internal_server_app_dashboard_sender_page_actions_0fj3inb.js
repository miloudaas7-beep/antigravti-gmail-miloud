module.exports=[11353,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_sender_page_actions_0fj3inb.js.map