module.exports=[62730,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_campaign_page_actions_0s-imrb.js.map