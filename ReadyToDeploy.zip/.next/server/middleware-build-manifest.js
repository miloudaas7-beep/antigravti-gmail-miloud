globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/G9A_pzCbopb-rFlSPTrlw/_buildManifest.js",
    "static/G9A_pzCbopb-rFlSPTrlw/_ssgManifest.js",
    "static/G9A_pzCbopb-rFlSPTrlw/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/15c0qix6i5tua.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0av98cua.cd9o.js",
    "static/chunks/0wt~c5i0-plwm.js",
    "static/chunks/turbopack-1276h~i9lxeg..js"
  ]
};
