var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/callback/route.js")
R.c("server/chunks/[root-of-the-server]__125j9kx._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/_next-internal_server_app_auth_callback_route_actions_09jr~mp.js")
R.m(76907)
module.exports=R.m(76907).exports
