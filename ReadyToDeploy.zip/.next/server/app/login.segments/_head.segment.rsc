1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/039nwuyffeq_9.js","/_next/static/chunks/0udu_dndsx8za.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/039nwuyffeq_9.js","/_next/static/chunks/0udu_dndsx8za.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/_next/static/chunks/039nwuyffeq_9.js","/_next/static/chunks/0udu_dndsx8za.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"SmartScout AI — Lead Generation & Cold Email Platform"}],["$","meta","1",{"name":"description","content":"AI-powered B2B lead discovery and automated cold email SaaS. Find leads, personalize with AI, and send at scale."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.0x3dzn~oxb6tn.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","3",{}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"G9A_pzCbopb-rFlSPTrlw"}
