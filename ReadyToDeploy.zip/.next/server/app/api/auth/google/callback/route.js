var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/google/callback/route.js")
R.c("server/chunks/[root-of-the-server]__0px~iru._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0u7r86d._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_google_callback_route_actions_0iytbyq.js")
R.m(85233)
module.exports=R.m(85233).exports
