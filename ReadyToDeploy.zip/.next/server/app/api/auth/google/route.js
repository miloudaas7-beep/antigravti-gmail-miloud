var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/google/route.js")
R.c("server/chunks/[root-of-the-server]__09y2o.l._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0u7r86d._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_google_route_actions_0fkkm_2.js")
R.m(88214)
module.exports=R.m(88214).exports
