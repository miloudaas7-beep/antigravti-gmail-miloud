var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/campaign/send-single/route.js")
R.c("server/chunks/[root-of-the-server]__0rtzdv5._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0u7r86d._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/_next-internal_server_app_api_campaign_send-single_route_actions_0q12_km.js")
R.m(15504)
module.exports=R.m(15504).exports
