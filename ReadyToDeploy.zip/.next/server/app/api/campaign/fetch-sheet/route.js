var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/campaign/fetch-sheet/route.js")
R.c("server/chunks/[root-of-the-server]__0arjc4d._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0u7r86d._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/_next-internal_server_app_api_campaign_fetch-sheet_route_actions_043s-wl.js")
R.m(58280)
module.exports=R.m(58280).exports
