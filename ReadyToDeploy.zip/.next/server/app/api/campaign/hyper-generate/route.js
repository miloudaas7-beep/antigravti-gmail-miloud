var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/campaign/hyper-generate/route.js")
R.c("server/chunks/[root-of-the-server]__0r47wmx._.js")
R.c("server/chunks/node_modules_@google_generative-ai_dist_index_mjs_07lt0._._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_campaign_hyper-generate_route_actions_0n12_5g.js")
R.m(18547)
module.exports=R.m(18547).exports
