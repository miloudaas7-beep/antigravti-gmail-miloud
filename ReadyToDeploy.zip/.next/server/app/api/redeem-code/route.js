var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/redeem-code/route.js")
R.c("server/chunks/[root-of-the-server]__0twhn5j._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/_next-internal_server_app_api_redeem-code_route_actions_09m0gyw.js")
R.m(92061)
module.exports=R.m(92061).exports
