var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/sender/start/route.js")
R.c("server/chunks/[root-of-the-server]__07vsdxw._.js")
R.c("server/chunks/[root-of-the-server]__0p3fo6l._.js")
R.c("server/chunks/[root-of-the-server]__0u7r86d._.js")
R.c("server/chunks/_0ms6rco._.js")
R.c("server/chunks/_next-internal_server_app_api_sender_start_route_actions_0zq0rl_.js")
R.m(35509)
module.exports=R.m(35509).exports
